#include <iostream>
using namespace std;

class Items{
	int number;
	float cost;
	
	public :
		void putdata()
		{
			cout<<"enter your number = "<<number<<endl;
			cout<<"enter your cost per :$ = "<<cost<<endl;
		}
		friend void getdata(Items &);
};
       void getdata(Items & object)
       {
       	cout<<"enter number of items "<<endl;
       	cin>>object.number;
       	cout<<"enter cost per items :$"<<endl;
       	cin>>object.cost;
	   }
	   
	   int main()
	   {
	   	Items item;
        getdata(item);
        cout << "\nItem Details:\n";
        item.putdata();
        return 0;
	   }
