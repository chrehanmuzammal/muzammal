#include<iostream>
using namespace std;

inline int sum(int a,int b)
{
	return a+b;
}
int main ()
{
	int a,b;
	cout<<"sum the value of a and b "<<endl;
	cin>>a>>b;
	cout<<"the sum value of a and b "<<sum(a,b)<<endl;
}
