#include<iostream>
#include <string>
using namespace std;

class employee
{
	private :
		string name;
		int id;
		float salary;
		
		public :
			void setdata(string empname,int empid,float empsalary)
			{
			name = empname;
			id = empid;
			salary = empsalary;
		}
		void displaydata()
		{
			cout<<" your name = "<<name<<endl;
			cout<<" your id = "<<id<<endl;
			cout<<" your salary = "<<salary<<endl;
		}
};
      int main()
      {
      	employee emp;
      	
      	string name;
      	int id; 
      	float salary;
      	
      	cout<<"enter your name = "<<endl;
      	getline(cin, name);
      	
        cout<<"enter your id = "<<endl;
		cin>>id;
		
		cout<<"enter your salary = "<<endl;
		cin>>salary;
		
		emp.setdata(name,id,salary);
		cout<<"\n employee details \n ";
		
		emp.displaydata();
	    return 0;		
	  }
