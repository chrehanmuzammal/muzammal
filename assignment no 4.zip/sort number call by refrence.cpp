#include<iostream>
using namespace std;
void sortnumber(int &a,int &b)
{
	if (a>b)
	{
		int temp = a;
		a = b;
		b = temp;
	}
 } 
 int main ()
 {
 	int a,b;
 	
 	cout<<"Enter two numbers:";
 	cin>>a>>b;
 	
 	sortnumber(a,b);
 	
 	cout<<"sorted numbers:"<<a<<" ,"<<b<<endl;
 	
 	return 0;
 }
